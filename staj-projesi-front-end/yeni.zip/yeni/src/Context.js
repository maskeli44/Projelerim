import axios from 'axios';
import React, { Component } from 'react'
const responseURL="http://localhost:8080";
const UserContext = React.createContext();
const reducer=async(state,action)=>{
  switch(action.type){
    case 'showCompany':
      return{...state,
        sirketTableData: {rows:state.sirketTableData.rows.filter(sirket=>action.payload!==sirket.id)}
      }
    case 'showIntership':{
      const ogrenciID=state.ogrenci.id
      const response=await axios.get(responseURL+"/getStudentApplication/"+ogrenciID);
      const jsonstring= JSON.stringify(response.data);
      const data = JSON.parse(jsonstring);
      state={
        stajlar:data,
      }
      break;
    }
    default:
      return state;
  }
}

export  class Context extends Component {
   state={
      sirketTableData : {
        columns: ['company_name','sector','email'],
        showColumns:['Şirket','Sektör','E-mail'],
        rows:[ ]
      },
      stajlar:[],
      ogrenci:{
        id:'22'
      }
      ,
      
      dispatch: action=>{
        this.setState(state=>reducer(state,action))
      },
   }  
  
  componentDidMount= async () =>{
    const response=await  axios.get(responseURL+"/showCompany");
    const jsonstring= JSON.stringify(response.data);
    const data = JSON.parse(jsonstring);
    this.setState({
      
      sirketTableData : {
        columns: ['company_name','sector','email'],
        showColumns:['Şirket','Sektör','E-mail'],
        rows:data,
      }
    })
      
  }

    
  render() {
    
    return (
      <UserContext.Provider value={this.state}>
        {this.props.children}
      </UserContext.Provider>
    )
  }
}

const UserConsumer = UserContext.Consumer;

export default UserConsumer;