import React, { Component } from 'react'

export default class AnaSayfa extends Component {
  render() {
    return (
      <div className='col'> 
        <br/>
        <h3  >Duyurular</h3>
        <hr/>
      </div>
    )
  }
}
