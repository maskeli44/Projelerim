
import React, { Component } from 'react'
import UserConsumer from '../Context';

export default class YeniStajModal extends Component {
   
    render(){
      return(
      <UserConsumer>
        {
          value=>{
            const {sirketTableData}=value;
            const deplisteleme=sirketTableData.rows.map(function(row){return(row.sector)});
            
            const sirlisteleme=sirketTableData.rows.map(function(row){return(row.company_name)});;
            function Listeler(liste){
                
                const sonListe=[] 
                liste.forEach(element => {
                    sonListe.push(<option key={element}>{element}</option>)
                });
                return(sonListe)
            }
            return(
          
              <div>
                <button
                  type="button"
                  className="btn btn-success"
                  data-bs-toggle="modal"
                  data-bs-target="#exampleModal"
                >
                  Yeni Staj Başvurusu
                </button>
                {/* Modal */}
                <div
                  className="modal fade"
                  id="exampleModal"
                  tabIndex={-1}
                  aria-labelledby="exampleModalLabel"
                  aria-hidden="true"
                >
                  <div className="modal-dialog">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="exampleModalLabel">
                          Yeni Staj Başvurusu
                        </h5>
                        <button
                          type="button"
                          className="btn-close"
                          data-bs-dismiss="modal"
                          aria-label="Close"
                        />
                      </div>
                      <div className="modal-body">
                          <div className="input-group mb-3">
                              
                              <select id="inputState" className="form-select " defaultValue={0} >
                                  <option >Şireket Seçiniz...</option>
                                  {
                                      Listeler(sirlisteleme)
                                  }
                              </select>
                              <span className="input-group-text">  </span>
                              <select id="inputState" className="form-select" defaultValue={0}>
                                  <option >Departman Seçiniz...</option>
                                  {
                                      Listeler(deplisteleme)
                                  }  
                              </select>
                          </div>
                            <div className="input-group mb-3">
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Staj Amiri"
                                aria-label="stajAmiri"
                              />
                              <span className="input-group-text">  </span>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Yapılacak Staj Gün Sayisi"
                                aria-label="departman"
                              />
                            </div>
                            <div className="input-group mb-3">
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Staj Başlama Tarihi"
                                aria-label="stajBaslamaTarihi"
                              />
                              <span className="input-group-text">  </span>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Staj Bitiş Tarihi"
                                aria-label="stajBitisTarihi"
                              />
                            </div>
                            <div className="input-group mb-3">
                                <textarea
                                  className="form-control"
                                  aria-label="adres"
                                  defaultValue={""}
                                  placeholder="Stajda Yapılması Planlanan Konu"
                              />
                            </div>
                            <div className="input-group mb-3">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Departmandaki Mühendis Sayısı"
                                  aria-label="muhSayi"
                                  id='muhSayi'
                                />
                                
                              </div>
              
                      </div>
                      <div className="modal-footer">
                        <button
                          type="button"
                          className="btn btn-secondary"
                          data-bs-dismiss="modal"
                        >
                          Kapat
                        </button>
                        <button type="button" className="btn btn-primary">
                          Kayıt
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )
          }
        }
      </UserConsumer>
      )
    }
  
    
  
}
