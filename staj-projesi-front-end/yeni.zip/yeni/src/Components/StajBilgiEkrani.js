import React, { Component } from 'react';
import uuid from 'react-uuid';
import UserConsumer from '../Context';
import YeniStajModal from './YeniStajModal';
export default class StajBilgiEkrani extends Component {
  constructor(props){
    super(props);
    this.state={
      isVisible: false,
      butonGecerliMi: true,
    }
  }
  
  onClickEvent=(e)=>{
    this.setState({
      isVisible: !this.state.isVisible,
    })
  }
  onButonEvent=(e)=>{
    this.setState({
      butonGecerliMi: !this.state.butonGecerliMi,
    })
  }
  onGetir=(dispatch,e,ogrenci)=>{
    
    dispatch({type:"showIntership",ogrenci});
  }
  render() {
    return(
      <UserConsumer>
      {
        value=>{
            const {dispatch}= value;
            const stajDonemi="2021-2022 dönemi";
            const state= this.state;
            const {isVisible}= this.state;
            const {ogrenci}=value;
            const stajBilgileri = ['web sitesi','20.06.2022','08.08.2022','30',true,'30']
            const {stajlar}=value;
            
            function stajlariGoster(){
              const staj=[];
              this.onGetir.bind(this,dispatch,ogrenci.id);
              staj.push(stajCard)
              return staj;
            }
            var cardBody=stajlar.map(function(row){
              
              <div className='card-body '>
                  <div className='row '>

                  </div>
              </div>
            })
            var stajCard=(
              
                <div className="card " style={{  }} id={uuid()}>
                <div className="card-header" ><h4 >{stajDonemi}</h4></div>
                {
                    isVisible ? 
                    <div className='card-body '>
                        <div className='row '>
                          
                          <div className='col'>Stajın Konusu: {stajBilgileri[0]}</div>
                          <div className='col'>Stajın Başlangıç Tarihi: {stajBilgileri[1]}</div>
                          <div className='col'>Stajın Bitiş Tarihi:{stajBilgileri[2]}</div>
                        </div>
                        <div className='row'>
                          <div className='col'>Stajın Gün Sayısı:{stajBilgileri[3]}</div>
                          <div className='col'>Komisyon Onayı:
                            
                            <input
                              className="form-check-input"
                              type="checkbox"
                              defaultValue=""
                              id="flexCheckDisabled"
                              defaultChecked={stajBilgileri[4]}
                              disabled
                            />
                              
                          </div>
                          <div className='col'>Kabul Edilen Gün Sayısı:{stajBilgileri[5]}</div>
                        </div>
                        <div className='row'>
                          <div className='col'>{}</div>
                          <div className='col'>{}</div>
                          <div className='col'>{}</div>
                        </div>
                        <div className='row'>
                          <div className='col'>{}</div>
                          <div className='col'>{}</div>
                          <div className='col'>{}</div>
                        </div>
        
                    </div>
                    : null 
                }
              </div>
              
            );
              
            
            return (
                <div className='col' id={uuid()}>
                <h4 id={uuid()}>Staj Listesi</h4>
                <div id={uuid()}>
                    {stajlariGoster() }
                </div>
                    <br/>
                    <br/>
                    <br/>
                <div className=''>
                    { state.butonGecerliMi ? <YeniStajModal/> : null}
                    
                </div>
                
              </div>
            )
          
        }
      }
    </UserConsumer>
    )
    
    
  }
}
