import React, { Component } from 'react'
import UserConsumer from '../Context';
import uuid from 'react-uuid';

 class TeacherPage extends Component {
    constructor(props){
        super(props);

      }
      
       
  render() {  
    
    return (
      <UserConsumer>
      {
        value=>{
          const {TeacherTableData} =value;
          var dataShowColumns=TeacherTableData.showColumns;
          var dataColumns = TeacherTableData.columns;
          var dataRows =  TeacherTableData.rows;
          
          var tableHeaders = (
              <tr>
                {dataShowColumns.map(function(column) {
                  return <th style={{width: '500px',height:'auto',"borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid',}} key={uuid()}>{column}</th>; })}
              </tr>
          );

          var tableBody = dataRows.map(function(row) {

              return (
                <tr key={uuid()}>
                  {dataColumns.map(function(column) {
                    return <td key={uuid()} style={{width:'auto',"borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid',}}>
                      {row[column]}
                      <button style={{width:'auto',"borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid',}} >
                        Detay
                      </button>
                      </td>; })}
                </tr>); });
           return (
              <div className='table col'>
                <table style={{"borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid', 'marginTop':'15px'}} className="table table-bordered table-hover" width="100%">
                    <thead>
                        {tableHeaders}
                    </thead>
                    <tbody style={{width: 'auto',height:'auto',"borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid',}}>
                    
                    {tableBody}
                    </tbody>
                </table>
                {
                    this.uyari
                }
                <ggf/>
              </div>

            )
        }
      }
    </UserConsumer>
    )
  }
}export default TeacherPage;
