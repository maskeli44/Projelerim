
import React, { Component } from 'react'
import uuid from 'react-uuid';
import YeniSirketKayit from './YeniSirketKayit';
import UserConsumer from '../Context';


export default class SirketUI2 extends Component {
    uyari="! Eğer Listede Şirketiniz Yok sa Yeni Kayıt Butonuna Basın Aksi Halde İşleminize Devam Edebilirsiniz!";
    
   
  render() {
    
    return(
      <UserConsumer>
        {
          value=>{
            const {dispatch}=value;
            const {sirketTableData} =value;
            var dataShowColumns=sirketTableData.showColumns;
            var dataColumns = sirketTableData.columns;
            var dataRows = sirketTableData.rows;
            
            var tableHeaders = (
                <tr>
                  {dataShowColumns.map(function(column) {
                    return <th style={{width: '500px',height:'auto',"borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid',}} key={uuid()}>{column}</th>; })}
                </tr>
            );

            var tableBody = dataRows.map(function(row) {

                return (
                  <tr key={uuid()}>
                    {dataColumns.map(function(column) {
                      return <td key={uuid()} style={{width:'auto',"borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid',}}>{row[column]}</td>; })}
                  </tr>); 
            });

            return (
              <div className='table col'>
                  <table style={{"borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid', 'marginTop':'15px'}} className="table table-bordered table-hover" width="100%">
                      <thead>
                          {tableHeaders}
                      </thead>
                      <tbody style={{width: 'auto',height:'auto',"borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid',}}>
                      
                      {tableBody}
                      </tbody>
                  </table>
                  {
                      this.uyari
                  }
                  <YeniSirketKayit/>
              </div>

            )
          }
        }
      </UserConsumer>
    )
   
  }
}
