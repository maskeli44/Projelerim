import React, { Component } from 'react'

export default class PopupSirketKeyitOnay extends Component {
  
  render() {
    return (
      <div className='modal-body'>
          
      </div>
      
    )
  }
}
