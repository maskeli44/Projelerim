import { isVisible } from '@testing-library/user-event/dist/utils'
import React, { Component } from 'react'
import UserConsumer from '../Context';




 class StudentUserLogin extends Component {
  constructor(props){
    super(props);
   // isVisible:true;
   this.state={
    user:'',
    password:''

  }
  }

  
  changeInput = (e)=>{
    this.setState({
      [e.target.id]:[e.target.value],
    })
    
  }
  
   
  
  render() {
    const props= this.props;
    var {user}= this.state;
    var {password}=this.state;
    function GirisYap(){
      if(user!==''&&password!==''){
        props.handlePageChange('AnaSayfa')
      }
    }
    return (
      <UserConsumer>
        {value=>{
          return(
            <div className="StudentUserLogin col">
            <form className="p-3 mb-2 bg-primary text-white">
             
            <div className="conteiner">
            <div className="row">
            <h1  className="col-md-8%3 offset-md+1" > Öğrenci Giriş Sayfası</h1>
            <div className="label">
         
                <label  className="form-label" >Öğrenci Numarası</label>
                    <input type="value" 
                    id="user" 
                     className="col-md-8%3 offset-md" 
                    autoComplete='off'
                    value={user}
                    onChange={this.changeInput}
                    required
                    />
                  
              </div>
                    <div className="col-md-5 offset-md-4" >
                      <label className="form-label">Şifre</label>
                          <input type="password" 
                              id="password"
                              onChange={this.changeInput}
                              value={password}
                              required 
                                 />
                                   </div>
                          <div id="passwordHelpBlock" 
                          className="col-md-8 offset-md-3" 
                          style={{color:"red"}}>
                          Şifreniz en az 8 karakter uzunluğunda olmalı, harf ve rakamlardan oluşmalı,özel karakter veya emoji içermemelidir.
                          </div>  
                            
                            <button   
                             className="col-md-2 offset-md-5 bg-danger text-white" onClick={GirisYap}
                             >
                               Giriş
                                </button>
            </div>
            </div>
            </form>
            
          </div>
          )
          
        }}
      </UserConsumer>
      
    )
  }
}
export default StudentUserLogin;